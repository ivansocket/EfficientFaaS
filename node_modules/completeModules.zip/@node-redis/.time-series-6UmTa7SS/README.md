# @node-redis/time-series
The sources and docs for this package are in the main [node-redis](https://github.com/redis/node-redis) repo.
