var v35 = require('./lib/v35.js');
var md5 = require('./lib/md5');

module.exports = v35('v3', 0x30, md5);