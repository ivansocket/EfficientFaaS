"use strict";
// Copyright 2021 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", { value: true });
exports.wrapUserFunction = void 0;
// eslint-disable-next-line node/no-deprecated-api
const domain = require("domain");
const logger_1 = require("./logger");
const invoker_1 = require("./invoker");
const cloud_events_1 = require("./cloud_events");
const redis = require('redis');
const express = require('express')
let cacheProvider = require('../../../../../cache-provider')
var fs = require('fs');
var crypto = require('crypto');
const CACHE_DURATION = 600
const propertyAccessTest = require("../../../../../ObjectPropertyAccessTest.json")
const imageThumbnail = require('image-thumbnail');
const Excel = require('exceljs')

const excel_manager = require("../../../../../excel-manager.js")
const functions_manager = require("../../../../../functions-manager.js")
/**
 * Get a completion handler that can be used to signal completion of an event function.
 * @param res the response object of the request the completion handler is for.
 * @returns an OnDoneCallback for the provided request.
 */
 var fs = require('fs');


const getOnDoneCallback = (res) => {
    return process.domain.bind((err, result) => {
        if (res.locals.functionExecutionFinished) {
            console.log('Ignoring extra callback call');
        }
        else {
            res.locals.functionExecutionFinished = true;
            if (err) {
                console.error(err.stack);
            }
            (0, invoker_1.sendResponse)(result, err, res);
        }
    });
};
/**
 * Helper function to parse a CloudEvent object from an HTTP request.
 * @param req an Express HTTP request
 * @returns a CloudEvent parsed from the request
 */
const parseCloudEventRequest = (req) => {
    let cloudEvent = req.body;
    if ((0, cloud_events_1.isBinaryCloudEvent)(req)) {
        cloudEvent = (0, cloud_events_1.getBinaryCloudEventContext)(req);
        cloudEvent.data = req.body;
    }
    return cloudEvent;
};
/**
 * Helper function to background event context and data payload object from an HTTP
 * request.
 * @param req an Express HTTP request
 * @returns the data playload and event context parsed from the request
 */
const parseBackgroundEvent = (req) => {
    const event = req.body;
    const data = event.data;
    let context = event.context;
    if (context === undefined) {
        // Support legacy events and CloudEvents in structured content mode, with
        // context properties represented as event top-level properties.
        // Context is everything but data.
        context = event;
        // Clear the property before removing field so the data object
        // is not deleted.
        context.data = undefined;
        delete context.data;
    }
    return { data, context };
};
/**
 * Wraps the provided function into an Express handler function with additional
 * instrumentation logic.
 * @param execute Runs user's function.
 * @return An Express handler function.
 */
const wrapHttpFunction = (execute) => {
    var firstFunctionCellCounter = 0
    var secondFunctionCellCounter = 0

    var isCached, finalTimeMicro

    var testTimes = true
    var countNotCached = 0
    var countNotCachedFunction2 = 0
    
    var workbook = new Excel.Workbook()
    var worksheet = workbook.addWorksheet('AverageExecutionTime')

    // workbook.xlsx.readFile('ExecutionMetrics.xlsx')
    // .then(function() {
    //     worksheet = workbook.getWorksheet(1);
    // })



    worksheet.columns = [
        {header: 'ImageSize', key: 'imageSize'},
        {header: 'In Process', key: 'inProcess'},
        {header: 'In Process Cached', key: 'inProcessCached'},
        {header: 'Out of Process', key: 'outOfProcess'},
        {header: 'Out of Process Cached', key: 'outOfProcessCached'},
        {header: 'Network', key: 'network'},
        {header: 'Network Cached', key: 'networkCached'}
      ]

      // force the columns to be at least as long as their header row.
// Have to take this approach because ExcelJS doesn't have an autofit property.
worksheet.columns.forEach(column => {
column.width = column.header.length < 12 ? 12 : column.header.length
})

// Make the header bold.
// Note: in Excel the rows are 1 based, meaning the first row is 1 instead of 0.
worksheet.getRow(1).font = {bold: true}

        //var redisClient = redis.createClient({});
        
        //redisClient.connect()

    return (req, res) => {
        const d = domain.create();
        // Catch unhandled errors originating from this request.
        d.on('error', err => {
            if (res.locals.functionExecutionFinished) {
                console.error(`Exception from a finished function: ${err}`);
            }
            else {
                res.locals.functionExecutionFinished = true;
                (0, logger_1.sendCrashResponse)({ err, res });
            }
        });

       // req.redisClient = redisClient

        cacheProvider.start()

        d.run(async () => {
            process.nextTick(async () => {

                //var imageData = req.body
                //var imageBase64 = "data:image/jpeg;base64," + imageData.toString('base64');


                //var imageDataImg = req.body.image
                //var imageBase64Img = "data:image/jpeg;base64," + imageDataImg.toString('base64');
                var functionName = process.argv[2].split('=')[1]
                //req.body[propertyAccessTest.property] = imageBase64
                req.body[propertyAccessTest.property] = req.body[propertyAccessTest.property].toString().replace("data:image/jpeg;base64,", "")
                var hash_key = crypto.createHash('sha256')
                .update(req.body[propertyAccessTest.property].toString())
                .digest('hex');

                req.hash_key = hash_key
        
                if(functionName == "secondTest") {
                    var redisClient = redis.createClient({});
                    redisClient.connect()
                    req.redisClient = redisClient
                }

                if (functionName == "firstTest" ) {
                    
                    var ffExecResult = await functions_manager.FirstFunctionExecution(execute, req, res, cacheProvider, firstFunctionCellCounter, countNotCached, testTimes, hash_key)
                    firstFunctionCellCounter = ffExecResult.firstFunctionCellCounter
                    isCached = ffExecResult.isCached
                    finalTimeMicro = ffExecResult.finalTimeMicro
                    countNotCached = ffExecResult.countNotCached

                    await excel_manager.InsertExcelData(worksheet, workbook, firstFunctionCellCounter, finalTimeMicro, isCached, "firstTest", req.body[propertyAccessTest.property].toString().length)
                    console.info("First test Final Time Micro:  %dmilliseconds", finalTimeMicro)
                }
                else if(functionName == "secondTest") {

                    var ffExecResult2 = await functions_manager.SecondFunctionExecution(execute, req, res, req.redisClient, secondFunctionCellCounter, countNotCachedFunction2, testTimes, hash_key)
                    secondFunctionCellCounter = ffExecResult2.secondFunctionCellCounter
                    isCached = ffExecResult2.isCached
                    finalTimeMicro = ffExecResult2.finalTimeMicro
                    countNotCachedFunction2 = ffExecResult2.countNotCachedFunction2

                    await excel_manager.InsertExcelData(worksheet, workbook, secondFunctionCellCounter, finalTimeMicro, isCached, "secondTest", req.body[propertyAccessTest.property].toString().length)
                    console.info("Second test Final Time Micro:  %dmilliseconds", finalTimeMicro)
                }
                else if(functionName == "thirdTest") {
                    try {

                        var redisClient =   redis.createClient({
                        url: 'redis://default:tfm02-redispassword@34.175.173.100:6379/0'
                    }) //redis.createClient({port:6379, host:"34.175.173.100", password: "tfm02-redispassword"})
                    await redisClient.connect()
                    req.redisClient = redisClient
                    await req.redisClient.set("KeyTest1", "ResultTest1")
                    var resultOfThird = await req.redisClient.get("KeyTest1")
                    //req.redisClient.set("AKey", "AValue")
                    //var testKeyRedisGCP = await req.redisClient.get("AKey")
                    var initialTime =  performance.now()

                    var redisCached =  await req.redisClient.get(hash_key.toString())

                    if (redisCached == 0 || redisCached == null) {
                        await execute(req, res);
                    }
                    else {
                        var res =  await req.redisClient.get(hash_key)
                        console.log("I am in Redis: " + res)
                    }

                    var finalTime =  performance.now() - initialTime
                    console.info("Third test Final Time:  %dms", finalTime)
                }
                catch(err) {
                    console.log("Exception: " + err)
                }
                }
            });
        });
    res.send("Executed successfully")
    };
};
/**
 * Wraps an async CloudEvent function in an express RequestHandler.
 * @param userFunction User's function.
 * @return An Express hander function that invokes the user function.
 */
const wrapCloudEventFunction = (userFunction) => {
    const httpHandler = (req, res) => {
        const callback = getOnDoneCallback(res);
        const cloudEvent = parseCloudEventRequest(req);
        Promise.resolve()
            .then(() => userFunction(cloudEvent))
            .then(result => callback(null, result), err => callback(err, undefined));
    };
    return wrapHttpFunction(httpHandler);
};
/**
 * Wraps callback style CloudEvent function in an express RequestHandler.
 * @param userFunction User's function.
 * @return An Express hander function that invokes the user function.
 */
const wrapCloudEventFunctionWithCallback = (userFunction) => {
    const httpHandler = (req, res) => {
        const callback = getOnDoneCallback(res);
        const cloudEvent = parseCloudEventRequest(req);
        return userFunction(cloudEvent, callback);
    };
    return wrapHttpFunction(httpHandler);
};
/**
 * Wraps an async event function in an express RequestHandler.
 * @param userFunction User's function.
 * @return An Express hander function that invokes the user function.
 */
const wrapEventFunction = (userFunction) => {
    const httpHandler = (req, res) => {
        const callback = getOnDoneCallback(res);
        const { data, context } = parseBackgroundEvent(req);
        Promise.resolve()
            .then(() => userFunction(data, context))
            .then(result => callback(null, result), err => callback(err, undefined));
    };
    return wrapHttpFunction(httpHandler);
};
/**
 * Wraps an callback style event function in an express RequestHandler.
 * @param userFunction User's function.
 * @return An Express hander function that invokes the user function.
 */
const wrapEventFunctionWithCallback = (userFunction) => {
    const httpHandler = (req, res) => {
        const callback = getOnDoneCallback(res);
        const { data, context } = parseBackgroundEvent(req);
        return userFunction(data, context, callback);
    };
    return wrapHttpFunction(httpHandler);
};
/**
 * Wraps a user function with the provided signature type in an express
 * RequestHandler.
 * @param userFunction User's function.
 * @return An Express hander function that invokes the user function.
 */
const wrapUserFunction = (userFunction, signatureType) => {
    switch (signatureType) {
        case 'http':
            return wrapHttpFunction(userFunction);
        case 'event':
            // Callback style if user function has more than 2 arguments.
            if (userFunction.length > 2) {
                return wrapEventFunctionWithCallback(userFunction);
            }
            return wrapEventFunction(userFunction);
        case 'cloudevent':
            if (userFunction.length > 1) {
                // Callback style if user function has more than 1 argument.
                return wrapCloudEventFunctionWithCallback(userFunction);
            }
            return wrapCloudEventFunction(userFunction);
    }
};
exports.wrapUserFunction = wrapUserFunction;
//# sourceMappingURL=function_wrappers.js.map