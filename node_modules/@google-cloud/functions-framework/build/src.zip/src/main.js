#!/usr/bin/env node
"use strict";
// Copyright 2019 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = void 0;
// Functions framework entry point that configures and starts Node.js server
// that runs user's code on HTTP request.
const loader_1 = require("./loader");
const invoker_1 = require("./invoker");
const server_1 = require("./server");
const options_1 = require("./options");
/**
 * Main entrypoint for the functions framework that loads the user's function
 * and starts the HTTP server.
 */
const main = async () => {
    try {
        const options = (0, options_1.parseOptions)();
        if (options.printHelp) {
            console.error(options_1.helpText);
            return;
        }
        const loadedFunction = await (0, loader_1.getUserFunction)(options.sourceLocation, options.target, options.signatureType);
        if (!loadedFunction) {
            console.error('Could not load the function, shutting down.');
            // eslint-disable-next-line no-process-exit
            process.exit(1);
        }
        const { userFunction, signatureType } = loadedFunction;
        const server = (0, server_1.getServer)(userFunction, signatureType);
        const errorHandler = new invoker_1.ErrorHandler(server);
        server
            .listen(options.port, () => {
            errorHandler.register();
            if (process.env.NODE_ENV !== 'production') {
                console.log('Serving function...');
                console.log(`Function: ${options.target}`);
                console.log(`Signature type: ${signatureType}`);
                console.log(`URL: http://localhost:${options.port}/`);
            }
        })
            .setTimeout(0); // Disable automatic timeout on incoming connections.
    }
    catch (e) {
        if (e instanceof options_1.OptionsError) {
            console.error(e.message);
            // eslint-disable-next-line no-process-exit
            process.exit(1);
        }
        throw e;
    }
};
exports.main = main;
// Call the main method to load the user code and start the http server.
(0, exports.main)();
//# sourceMappingURL=main.js.map