export declare const FUNCTION_STATUS_HEADER_FIELD = "X-Google-Status";
/**
 * List of function signature types that are supported by the framework.
 */
export declare const SignatureType: readonly ["http", "event", "cloudevent"];
/**
 * Union type of all valid function SignatureType values.
 */
export declare type SignatureType = typeof SignatureType[number];
/**
 * Type guard to test if a provided value is valid SignatureType
 * @param x the value to test
 * @returns true if the provided value is a valid SignatureType
 */
export declare const isValidSignatureType: (x: any) => x is "event" | "http" | "cloudevent";
//# sourceMappingURL=types.d.ts.map