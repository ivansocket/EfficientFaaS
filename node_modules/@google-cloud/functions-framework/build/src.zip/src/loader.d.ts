import { HandlerFunction } from './functions';
import { SignatureType } from './types';
export declare const MIN_NODE_VERSION_ESMODULES = "13.2.0";
/**
 * Returns user's function from function file.
 * Returns null if function can't be retrieved.
 * @return User's function or null.
 */
export declare function getUserFunction(codeLocation: string, functionTarget: string, signatureType: SignatureType): Promise<{
    userFunction: HandlerFunction;
    signatureType: SignatureType;
} | null>;
//# sourceMappingURL=loader.d.ts.map