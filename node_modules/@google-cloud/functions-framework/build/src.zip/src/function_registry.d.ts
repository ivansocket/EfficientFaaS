import { HttpFunction, CloudEventFunction, HandlerFunction } from './functions';
import { SignatureType } from './types';
interface RegisteredFunction<T> {
    signatureType: SignatureType;
    userFunction: HandlerFunction<T>;
}
/**
 * Returns true if the function name is valid
 * - must contain only alphanumeric, numbers, or dash characters
 * - must be <= 63 characters
 * - must start with a letter
 * - must end with a letter or number
 * @param functionName the function name
 * @returns true if the function name is valid
 */
export declare const isValidFunctionName: (functionName: string) => boolean;
/**
 * Get a declaratively registered function
 * @param functionName the name with which the function was registered
 * @returns the registered function and signature type or undefined no function matching
 * the provided name has been registered.
 */
export declare const getRegisteredFunction: (functionName: string) => RegisteredFunction<any> | undefined;
/**
 * Register a function that responds to HTTP requests.
 * @param functionName - the name of the function
 * @param handler - the function to invoke when handling HTTP requests
 * @public
 */
export declare const http: (functionName: string, handler: HttpFunction) => void;
/**
 * Register a function that handles CloudEvents.
 * @param functionName - the name of the function
 * @param handler - the function to trigger when handling CloudEvents
 * @public
 */
export declare const cloudEvent: <T = unknown>(functionName: string, handler: CloudEventFunction<T>) => void;
export {};
//# sourceMappingURL=function_registry.d.ts.map