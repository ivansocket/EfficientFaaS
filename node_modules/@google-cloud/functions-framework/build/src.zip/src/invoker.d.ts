/// <reference types="node" />
import * as express from 'express';
import * as http from 'http';
export declare const setLatestRes: (res: express.Response) => void;
/**
 * Sends back a response to the incoming request.
 * @param result Output from function execution.
 * @param err Error from function execution.
 * @param res Express response object.
 */
export declare function sendResponse(result: any, err: Error | null, res: express.Response): void;
/**
 * Enables registration of error handlers.
 * @param server HTTP server which invokes user's function.
 * @constructor
 */
export declare class ErrorHandler {
    private readonly server;
    constructor(server: http.Server);
    /**
     * Registers handlers for uncaught exceptions and other unhandled errors.
     */
    register(): void;
}
//# sourceMappingURL=invoker.d.ts.map