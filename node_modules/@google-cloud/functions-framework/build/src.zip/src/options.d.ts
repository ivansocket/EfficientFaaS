import { SignatureType } from './types';
/**
 * Error thrown when an invalid option is provided.
 */
export declare class OptionsError extends Error {
}
/**
 * The set of all options that can be used to configure the behaviour of
 * the framework.
 */
export interface FrameworkOptions {
    /**
     * The port on which this server listens to all HTTP requests.
     */
    port: string;
    /**
     * The name of the function within user's node module to execute. If such a
     * function is not defined, then falls back to 'function' name.
     */
    target: string;
    /**
     * The path to the source code file containing the client function.
     */
    sourceLocation: string;
    /**
     * The signature type of the client function.
     */
    signatureType: SignatureType;
    /**
     * Whether or not the --help CLI flag was provided.
     */
    printHelp: boolean;
}
export declare const helpText = "Example usage:\n  functions-framework --target=helloWorld --port=8080\nDocumentation:\n  https://github.com/GoogleCloudPlatform/functions-framework-nodejs";
/**
 * Parse the configurable framework options from the provided CLI arguments and
 * environment variables.
 * @param cliArgs the raw command line arguments
 * @param envVars the environment variables to parse options from
 * @returns the parsed options that should be used to configure the framework.
 */
export declare const parseOptions: (cliArgs?: string[], envVars?: NodeJS.ProcessEnv) => FrameworkOptions;
//# sourceMappingURL=options.d.ts.map