import { Server } from 'http';
import { HandlerFunction } from '.';
/**
 * Testing utility for retrieving a function registered with the Functions Framework
 * @param functionName the name of the function to get
 * @returns a function that was registered with the Functions Framework
 *
 * @beta
 */
export declare const getFunction: (functionName: string) => HandlerFunction | undefined;
/**
 * Create an Express server that is configured to invoke a function that was
 * registered with the Functions Framework. This is a useful utility for testing functions
 * using [supertest](https://www.npmjs.com/package/supertest).
 * @param functionName the name of the function to wrap in the test server
 * @returns a function that was registered with the Functions Framework
 *
 * @beta
 */
export declare const getTestServer: (functionName: string) => Server;
//# sourceMappingURL=testing.d.ts.map