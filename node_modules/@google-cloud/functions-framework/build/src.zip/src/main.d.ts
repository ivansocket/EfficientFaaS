#!/usr/bin/env node
/**
 * Main entrypoint for the functions framework that loads the user's function
 * and starts the HTTP server.
 */
export declare const main: () => Promise<void>;
//# sourceMappingURL=main.d.ts.map