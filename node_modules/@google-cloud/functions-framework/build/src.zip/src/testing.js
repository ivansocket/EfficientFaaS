"use strict";
// Copyright 2021 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTestServer = exports.getFunction = void 0;
const function_registry_1 = require("./function_registry");
const server_1 = require("./server");
/**
 * Testing utility for retrieving a function registered with the Functions Framework
 * @param functionName the name of the function to get
 * @returns a function that was registered with the Functions Framework
 *
 * @beta
 */
const getFunction = (functionName) => {
    var _a;
    return (_a = (0, function_registry_1.getRegisteredFunction)(functionName)) === null || _a === void 0 ? void 0 : _a.userFunction;
};
exports.getFunction = getFunction;
/**
 * Create an Express server that is configured to invoke a function that was
 * registered with the Functions Framework. This is a useful utility for testing functions
 * using [supertest](https://www.npmjs.com/package/supertest).
 * @param functionName the name of the function to wrap in the test server
 * @returns a function that was registered with the Functions Framework
 *
 * @beta
 */
const getTestServer = (functionName) => {
    const registeredFunction = (0, function_registry_1.getRegisteredFunction)(functionName);
    if (!registeredFunction) {
        throw new Error(`The provided function "${functionName}" was not registered. Did you forget to require the module that defined it?`);
    }
    return (0, server_1.getServer)(registeredFunction.userFunction, registeredFunction.signatureType);
};
exports.getTestServer = getTestServer;
//# sourceMappingURL=testing.js.map