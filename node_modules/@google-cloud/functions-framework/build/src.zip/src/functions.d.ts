/// <reference types="node" />
import { Request as ExpressRequest, Response } from 'express';
import { CloudEventV1 as CloudEvent } from 'cloudevents';
/**
 * @public
 */
export { CloudEvent };
/**
 * @public
 */
export interface Request extends ExpressRequest {
    /**
     * A buffer which provides access to the request's raw HTTP body.
     */
    rawBody?: Buffer;
}
/**
 * @public
 */
export { Response };
/**
 * A HTTP function handler.
 * @public
 */
export interface HttpFunction {
    (req: Request, res: Response): any;
}
/**
 * A legacy event function handler.
 * @public
 */
export interface EventFunction {
    (data: {}, context: Context): any;
}
/**
 * A legacy event function handler with callback.
 * @public
 */
export interface EventFunctionWithCallback {
    (data: {}, context: Context, callback: Function): any;
}
/**
 * A CloudEvent function handler.
 * @public
 */
export interface CloudEventFunction<T = unknown> {
    (cloudEvent: CloudEvent<T>): any;
}
/**
 * A CloudEvent function handler with callback.
 * @public
 */
export interface CloudEventFunctionWithCallback<T = unknown> {
    (cloudEvent: CloudEvent<T>, callback: Function): any;
}
/**
 * A function handler.
 * @public
 */
export declare type HandlerFunction<T = unknown> = HttpFunction | EventFunction | EventFunctionWithCallback | CloudEventFunction<T> | CloudEventFunctionWithCallback<T>;
/**
 * A legacy event.
 * @public
 */
export interface LegacyEvent {
    data: {
        [key: string]: any;
    };
    context: CloudFunctionsContext;
}
/**
 * A data object used for legacy event functions.
 * @public
 */
export interface Data {
    data: object;
}
/**
 * A legacy event function context.
 * @public
 */
export declare type LegacyCloudFunctionsContext = CloudFunctionsContext | Data;
/**
 * The Cloud Functions context object for the event.
 * {@link https://cloud.google.com/functions/docs/writing/background#function_parameters}
 * @public
 */
export interface CloudFunctionsContext {
    /**
     * A unique ID for the event. For example: "70172329041928".
     */
    eventId?: string;
    /**
     * The date/time this event was created. For example: "2018-04-09T07:56:12.975Z"
     * This will be formatted as ISO 8601.
     */
    timestamp?: string;
    /**
     * The type of the event. For example: "google.pubsub.topic.publish".
     */
    eventType?: string;
    /**
     * The resource that emitted the event.
     */
    resource?: string | {
        [key: string]: string;
    };
}
/**
 * The function's context.
 * @public
 */
export declare type Context = CloudFunctionsContext | CloudEvent<unknown>;
//# sourceMappingURL=functions.d.ts.map